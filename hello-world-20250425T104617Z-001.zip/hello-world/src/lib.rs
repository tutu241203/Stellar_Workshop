#![no_std]
use soroban_sdk::{contract, contractimpl, contracttype, Env, Address, String, Vec, Symbol, symbol_short, log};

#[contracttype]
#[derive(Clone)]
pub struct TransactionRecord {
    pub sender: Address,
    pub receiver: Address,
    pub amount: u64,
    pub message: String,
    pub timestamp: u64,
}

#[contracttype]
pub enum ExplorerKey {
    Record(u64),
    Count,
}

#[contract]
pub struct BlockchainExplorerLite;

#[contractimpl]
impl BlockchainExplorerLite {
    pub fn add_transaction(env: Env, sender: Address, receiver: Address, amount: u64, message: String) -> u64 {
        let mut count: u64 = env.storage().instance().get(&ExplorerKey::Count).unwrap_or(0);
        count += 1;

        let record = TransactionRecord {
            sender,
            receiver,
            amount,
            message,
            timestamp: env.ledger().timestamp(),
        };

        env.storage().instance().set(&ExplorerKey::Record(count), &record);
        env.storage().instance().set(&ExplorerKey::Count, &count);

        log!(&env, "Transaction logged with ID: {}", count);
        count
    }

    pub fn view_transaction(env: Env, tx_id: u64) -> TransactionRecord {
        env.storage().instance().get(&ExplorerKey::Record(tx_id)).unwrap()
    }

    pub fn get_total_transactions(env: Env) -> u64 {
        env.storage().instance().get(&ExplorerKey::Count).unwrap_or(0)
    }
}
